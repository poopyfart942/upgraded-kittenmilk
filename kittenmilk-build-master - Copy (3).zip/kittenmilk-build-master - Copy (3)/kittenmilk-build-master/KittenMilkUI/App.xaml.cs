﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace KittenMilkUI
{
    /// <summary>
    /// Interaction logic for App.xaml
  
    public partial class App : Application
    {
    }

}
